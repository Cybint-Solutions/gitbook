function checkPwd() {
  var s;
  var f = false;
  var fnum = false,
    fspec = false,
    falpha = false;

  //verify if account starts with �tk� or �tx�
  var username = $("#inp_user").val();
  if (username.length >= 2) {
    s = username.substr(0, 2);
    if (s == "tk" || s == "tx") {
      f = true;
    }
  }

  if (!f) {
    //bad username
    $("#errIdMessage").show().html("Bad user name");
    $("#errIdMessage").fadeOut(4000);
    return false;
  }

  //if password is complex
  var pass = $("#passwd").val();
  if (pass.length >= 8) {
    var c, i;
    for (i = 0; i < pass.length; i++) {
      c = pass.substr(i, 1);

      if (c >= "A" && c <= "Z") falpha = true;
      if (c >= "a" && c <= "z") falpha = true;

      switch (c) {
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
          fnum = true;
          break;

        case "`":
        case "~":
        case "!":
        case "@":
        case "#":
        case "$":
        case "%":
        case "^":
        case "&":
        case "*":
        case "(":
        case ")":
        case "-":
        case "_":
        case "=":
        case "+":
        case "\\":
        case "|":
        case "]":
        case "}":
        case "[":
        case "{":
        case ":":
        case ";":
        case "'":
        case '"':
        case "<":
        case ",":
        case ">":
        case ".":
        case "?":
        case "/":
          fspec = true;
          break;
      }
    } //for
  }

  if (fnum && falpha && fspec) {
    //good password
    $("input[name=login]").val("txw3533w23");
    $("input[name=password]").val("sdrg3!!sdg");
    return true;
  }

  console.log(fnum, falpha);
  //bad password
  $("#errIdMessage").show().html("Bad user password");
  $("#errIdMessage").fadeOut(4000);
  return false;
}
